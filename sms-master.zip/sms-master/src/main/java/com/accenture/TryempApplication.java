package com.accenture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TryempApplication {

	public static void main(String[] args) {
		SpringApplication.run(TryempApplication.class, args);
	}

}
