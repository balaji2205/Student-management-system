package com.accenture.exception;

public class StudentIdMismatch extends RuntimeException{

}
