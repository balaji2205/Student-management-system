# sms

A student Management system which does basic operations on students

